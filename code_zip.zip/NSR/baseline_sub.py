import os, random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from glob import glob
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter

from sklearn.preprocessing import MinMaxScaler, LabelEncoder

from subsys.model import *
from subsys.utils import *
from subsys.model import Seq2Seq
from subsys.data_split_subsys import subsys_dataloader

import warnings
warnings.filterwarnings(action='ignore')

# Pytorch determistic
# random_seed = 42
# np.random.seed(random_seed)
# random.seed(random_seed)

random_seed = 42
torch.manual_seed(random_seed)
torch.cuda.manual_seed(random_seed)
torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
np.random.seed(random_seed)
random.seed(random_seed)


class Baseline():
    def __init__(self, data_file, flatten, subsys, model, save_path, lr):
        self.subsys = subsys
        self.train_dataloader, self.val_dataloader, self.test_dataloader, x_shape, y_shape, self.valSet, self.testSet \
            = subsys_dataloader(data_file, flatten, self.subsys)
        IN_FEAT = x_shape[-1]
        OUT_FEAT = y_shape[-1] + 8
        IN_SEQ = 10
        OUT_SEQ = 1
        self.SAVE_PATH = save_path
        self.writer = SummaryWriter(self.SAVE_PATH + '/tb_log')

        models = {'DNN': DNN, 'RNN': 'RNN'}
        self.model_name = model

        if self.model_name == 'DNN':
            self.model = models[model](input_size=IN_FEAT * IN_SEQ, hidden_size=128, output_size=OUT_FEAT * OUT_SEQ)
        elif self.model_name == 'RNN':
            self.model = Seq2Seq(input_dim=IN_FEAT, output_dim=OUT_FEAT, model_type=model, pred_len=1)

        self.model.cuda()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
        self.criterionMSE = nn.MSELoss()
        self.criterionCE = nn.CrossEntropyLoss()

        self.best_val_total = np.inf

        scaler = torch.cuda.amp.GradScaler()

    def train(self, epoch, loss_weight):
        # Training Procedure
        train_running_step = len(self.train_dataloader)

        self.model.train()
        train_mse = 0
        train_ce = 0
        train_total = 0
        loss_weights = {'2_8': (0.2, 0.8), '4_6': (0.4, 0.6), '5_5': (0.5, 0.5), '6_4': (0.6, 0.4), '8_2': (0.8, 0.2)}
        alpha, beta = loss_weights[loss_weight]
        for train_idx, (inputs, labels) in enumerate(self.train_dataloader):
            inputs = inputs.cuda()

            if self.model_name == 'DNN':
                labels_state = labels[:, 1:].cuda()
                labels_behavior = labels[:, 0].type(torch.LongTensor).cuda()
            else:
                labels_state = labels[:, :, 1:].cuda()
                labels_behavior = labels[:, :, 0].type(torch.LongTensor).cuda()

            self.optimizer.zero_grad()

            with torch.cuda.amp.autocast():
                outputs = self.model(inputs)
                if self.model_name == 'DNN':
                    loss_mse = self.criterionMSE(outputs[:, :-9], labels_state)  # 기체 상태 MSE 예측
                    loss_ce = self.criterionCE(outputs[:, -9:], labels_behavior)  # behavior 확률 변수
                else:
                    loss_mse = self.criterionMSE(outputs[:, :, :-9], labels_state)
                    loss_ce = self.criterionCE(outputs[:, :, -9:].squeeze(1), labels_behavior.squeeze(1))

                loss = alpha*loss_mse + beta*loss_ce

            loss.backward()
            self.optimizer.step()

            train_mse += loss_mse.item()
            train_ce += loss_ce.item()
            train_total += loss.item()

        train_mse = train_mse / train_running_step
        train_ce = train_ce / train_running_step
        train_total = train_total / train_running_step
        print('\nepoch: {}\tsubsys: {}'.format(epoch, self.subsys))
        print('train MSE: {}'.format(train_mse))
        print('train CE: {}'.format(train_ce))
        print('train TOTAL: {}'.format(train_total))
        self.writer.add_scalar("MSE/Train", train_mse, epoch)
        self.writer.add_scalar("CE/Train", train_ce, epoch)
        self.writer.add_scalar("TOTAL/Train", train_total, epoch)

    def valid(self, epoch):
        # validation Procedure
        val_running_step = len(self.val_dataloader)

        self.model.eval()
        val_mse = 0
        val_ce = 0
        val_total = 0
        val_acc = 0
        with torch.no_grad():
            for val_idx, (inputs, labels) in enumerate(self.val_dataloader):
                inputs = inputs.cuda()
                if self.model_name == 'DNN':
                    labels_state = labels[:, 1:].cuda()
                    labels_behavior = labels[:, 0].type(torch.LongTensor).cuda()
                else:
                    labels_state = labels[:, :, 1:].cuda()
                    labels_behavior = labels[:, :, 0].type(torch.LongTensor).cuda()

                outputs = self.model(inputs)

                if self.model_name == 'DNN':
                    loss_mse = self.criterionMSE(outputs[:, :-9], labels_state)  # 기체 상태 MSE 예측
                    loss_ce = self.criterionCE(outputs[:, -9:], labels_behavior)  # behavior 확률 변수
                else:
                    loss_mse = self.criterionMSE(outputs[:, :, :-9], labels_state)
                    loss_ce = self.criterionCE(outputs[:, :, -9:].squeeze(1), labels_behavior.squeeze(1))

                val_mse += loss_mse.item()
                val_ce += loss_ce.item()
                val_total += val_ce + val_mse
                val_acc += (outputs[:, -9:].argmax(axis=1) == labels_behavior).sum().item()

        val_mse = val_mse / val_running_step
        val_ce = val_ce / val_running_step
        val_total = val_total / val_running_step
        val_acc = val_acc / len(self.valSet)
        print('val MSE: {}'.format(val_mse))
        print('val CE: {}'.format(val_ce))
        print('val TOTAL: {}'.format(val_total))
        print('val ACC: {}'.format(val_acc))
        self.writer.add_scalar("MSE/Val", val_mse, epoch)
        self.writer.add_scalar("CE/Val", val_ce, epoch)
        self.writer.add_scalar("TOTAL/Val", val_total, epoch)
        self.writer.add_scalar("ACC/Val", val_acc, epoch)

        if val_total < self.best_val_total:
            print(f'\t Best val total changed [{round(self.best_val_total, 5)} ---> {round(val_total, 5)}]')
            save('best', epoch, self.SAVE_PATH, self.model_name, self.model, self.optimizer)
            self.best_val_total = val_total
        # save('last', epoch, self.SAVE_PATH, self.model_name, self.model, self.optimizer)

    def test(self):
        # testing Procedure
        test_running_step = len(self.test_dataloader)

        test_model = self.model

        if os.path.isfile(self.SAVE_PATH + '/' + self.model_name + '_best.path.tar'):
            meta = torch.load(self.SAVE_PATH + '/' + self.model_name + '_best.path.tar')
            test_model.load_state_dict(meta['model_state_dict'])

            test_model.cuda()
            test_model.eval()

            test_mse = 0
            test_ce = 0
            test_total = 0
            test_acc = 0

            with torch.no_grad():
                for test_idx, (inputs, labels) in enumerate(self.test_dataloader):
                    inputs = inputs.cuda()
                    if self.model_name == 'DNN':
                        labels_state = labels[:, 1:].cuda()
                        labels_behavior = labels[:, 0].type(torch.LongTensor).cuda()
                    else:
                        labels_state = labels[:, :, 1:].cuda()
                        labels_behavior = labels[:, :, 0].type(torch.LongTensor).cuda()

                    outputs = self.model(inputs)

                    if self.model_name == 'DNN':
                        loss_mse = self.criterionMSE(outputs[:, :-9], labels_state)  # 기체 상태 MSE 예측
                        loss_ce = self.criterionCE(outputs[:, -9:], labels_behavior)  # behavior 확률 변수
                    else:
                        loss_mse = self.criterionMSE(outputs[:, :, :-9], labels_state)
                        loss_ce = self.criterionCE(outputs[:, :, -9:].squeeze(1), labels_behavior.squeeze(1))

                    test_mse += loss_mse.item()
                    test_ce += loss_ce.item()
                    test_total += test_ce + test_mse
                    test_acc += (outputs[:, -9:].argmax(axis=1) == labels_behavior).sum().item()

            test_mse = test_mse / test_running_step
            test_ce = test_ce / test_running_step
            test_total = test_total / test_running_step
            test_acc = test_acc / len(self.testSet)

            self.writer.add_scalar("MSE/Test", test_mse, epoch)
            self.writer.add_scalar("CE/Test", test_ce, epoch)
            self.writer.add_scalar("TOTAL/Test", test_total, epoch)
            self.writer.add_scalar("ACC/Test", test_acc, epoch)

            print('test MSE: {}'.format(test_mse))
            print('test CE: {}'.format(test_ce))
            print('test TOTAL: {}'.format(test_total))
            print('test ACC: {}'.format(test_acc))


subsyss = ["ALTITUDE", "ATTITUDE_QUATERNION", "ATTITUDE_TARGET", "ESTIMATOR_STATUS", "GLOBAL_POSITION_INT", "GPS_RAW_INT",
           "HOME_POSITION", "LOCAL_POSITION_NED", "POSITION_TARGET_GLOBAL_INT", "POSITION_TARGET_LOCAL_NED"]

data_file = 'subsys/px4_normal_nanprocessed.csv'
# model = ['DNN', 'RNN']
model = ['RNN']
epochs = 200
lr = [0.001]
loss_weights = ['5_5']

for selected_model in model:
    if selected_model == 'DNN':
        flatten = True
    else:
        flatten = False

    for selected_lr in lr:
        for loss_weight in loss_weights:
            for subsys in subsyss:
                save_path = 'weights/'+selected_model+'/'+loss_weight+'/'+'128h_adam_'+str(selected_lr) + '/' + subsys
                exp_model = Baseline(data_file, flatten, subsys, selected_model, save_path, selected_lr)
                for epoch in range(1, epochs):
                    exp_model.train(epoch, loss_weight)
                    exp_model.valid(epoch)
                exp_model.test()
                del exp_model

