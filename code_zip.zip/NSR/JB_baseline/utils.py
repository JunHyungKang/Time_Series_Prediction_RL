import os, torch
import numpy as np
from tqdm import tqdm
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import random

# Utils.py
def split_series(series, n_past, n_future):
    '''
    :param series: input time series
    :param n_past: number of past observations
    :param n_future: number of future series
    :return: X, y(label)
    '''
    X, y = list(), list()
    for window_start in range(len(series)):
        past_end = window_start + n_past
        future_end = past_end + n_future
        if future_end > len(series):
            break
        # slicing the past and future parts of the window
        past, future = series[window_start:past_end, :], series[past_end:future_end, :]
        X.append(past)
        y.append(future)
    return np.array(X), np.array(y)


def split_series_v2(series, ison_dict, n_past, n_future):
    '''
    :param series: input time series
    :param n_past: number of past observations
    :param n_future: number of future series without 동작여부
    :return: X, y(label)
    by jj
    '''
    X, y = list(), list()
    label_column = np.delete(np.arange(series.shape[1]), np.array(list(ison_dict.values())))
    
    for window_start in range(len(series)):
        past_end = window_start + n_past
        future_end = past_end + n_future
        if future_end > len(series):
            break
        # slicing the past and future parts of the window
        past, future = series[window_start:past_end, :], series[past_end:future_end, label_column]
        X.append(past)
        y.append(future)
    return np.array(X), np.array(y)


def normalize_and_split(arr, window=1):
    scalers  = []
    Xs = []
    ys = []
    
    seq_idx = arr[:,0]
    candidate_sequence = np.unique(seq_idx)
    
    for each_sequence in tqdm(candidate_sequence):
        
        # Get each Sequence
        candidate_idx = seq_idx == each_sequence
        each_seq_arr = arr[candidate_idx][:, 1:]
        
        # Normalize
        s = MinMaxScaler()
        normed = s.fit_transform(each_seq_arr)
        
        # Split
        X, y = split_series(normed, window, 1)
        Xs.append(X)
        ys.append(y)
        scalers.append(s)
        
    #return scalers, np.vstack(Xs), np.vstack(ys)
    return scalers, Xs, ys


def save(state, epoch, save_dir, model, optim, is_parallel=None):
    os.makedirs(save_dir, exist_ok=True)
    path = f'{save_dir}/{state}.path.tar'
    
    with open(path, "wb") as f:
        if not is_parallel:
            torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optim_state_dict': optim.state_dict()}, f)
        else:
            torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.module.state_dict(),
                    'optim_state_dict': optim.state_dict()}, f)
            
            
class CustomDataset(torch.utils.data.Dataset):
    def __init__(self, data, label, flatten=False, which='both'):
        self.data = data
        self.label = label
        self.flatten = flatten
        self.which = which

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        data = self.data[idx]
        label = self.label[idx]
        
        if self.flatten:
            if self.which == 'input':
                data = data.reshape(-1)
            elif self.which == 'output':
                label = label.reshape(-1)
            elif self.which == 'both':
                data = data.reshape(-1)
                label = label.reshape(-1)
        
        data = torch.Tensor(data)
        rl_data = torch.Tensor(data.reshape(-1))
        label = torch.Tensor(label)
        rl_label = torch.Tensor(label.reshape(-1))
        
        return data, label, rl_data, rl_label
    
    
class Vocabulary(object):
    """Simple vocabulary wrapper."""
    def __init__(self):
        self.word2idx = {}
        self.idx2word = {}
        self.idx = 0

    def add_word(self, word):
        if not word in self.word2idx:
            self.word2idx[word] = self.idx
            self.idx2word[self.idx] = word
            self.idx += 1

    def __call__(self, word):
        return self.word2idx[word]

    def __len__(self):
        return len(self.word2idx)


class ValueVocab(object):
    """Simple vocabulary wrapper."""
    def __init__(self):
        self.col2min = {}
        self.col2max = {}
        self.idx = 0

    def add_word(self, word, min, max):
        if (not word in self.col2min) and (not word in self.col2max):
            self.col2min[word] = min
            self.col2max[word] = max

    def __call__(self, word):
        return self.col2min[word], self.col2max[word]

    def __len__(self):
        return len(self.col2min)
    
    
class CustomScaler(object):
    def __init__(self):
        self.vv = ValueVocab()
    
    def fit_transform(self, data, column):
        norm_lambda = lambda x: (x-min(x))/(max(x)-min(x))

        for each_column in column:
            min_val = min(data[each_column])
            max_val = max(data[each_column])
            self.vv.add_word(each_column, min_val, max_val)
            if min_val == 0 and max_val == 0:
                data[each_column] = 0
            else:
                data[each_column] = norm_lambda(data[each_column])
        return data
    
    def transform(self, data, column):
        for each_column in column:
            min_val = self.vv.col2min[each_column]
            max_val = self.vv.col2max[each_column]
            
            if min_val == 0 and max_val == 0:
                data[each_column] = 0
            else:
                data[each_column] = (data[each_column]-min_val) / (max_val-min_val)
        return data