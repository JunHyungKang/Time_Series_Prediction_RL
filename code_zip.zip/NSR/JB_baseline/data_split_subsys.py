import numpy as np
import pandas as pd

from model import *
from utils import *

# from subsys.model import *
# from subsys.utils import *

def split_behavior(df, behavior):
    behavior_index_value = df[df['0_behavior'] == behavior].index.values
    idx_for_behavior = np.where(behavior_index_value[1:] - behavior_index_value[:-1] > 1)[0] + 1
    return idx_for_behavior

def get_scenario(data):
    prepare_idx = split_behavior(data, 'prepare')
    takeoff_idx = split_behavior(data, 'takeoff')
    forward_idx = split_behavior(data, 'forward')
    backward_idx = split_behavior(data, 'backward')
    right_idx = split_behavior(data, 'right')
    left_idx = split_behavior(data, 'left')
    up_idx = split_behavior(data, 'up')
    down_idx = split_behavior(data, 'down')
    land_idx = split_behavior(data, 'land')
    behavior_idx = [prepare_idx, takeoff_idx, forward_idx, backward_idx, right_idx, left_idx, up_idx, down_idx,
                    land_idx]
    scenarios = [np.sum(np.asarray(behavior_idx)[:, each_idx]) for each_idx in range(len(prepare_idx))]
    scenarios.append(len(data))

    scenario_list = [None for _ in range(len(data))]
    start = 0
    for scenario_num, scenario_idx in enumerate(scenarios):
        for i in range(start, scenario_idx):
            scenario_list[i] = scenario_num
        start = scenario_idx
    return scenario_list, scenarios

def normalize_v1(data, ison_list, train=50, val=5, test=10):
    random_scenario = np.random.permutation(np.unique(data['scenario']))

    print(random_scenario)

    train_scenario = random_scenario[:train]
    val_scenario = random_scenario[train:train + val]
    test_scenario = random_scenario[train + val:train + val + test]

    train_scaler = []
    val_scaler = []
    test_scaler = []

    train_normalized = []
    val_normalized = []
    test_normalized = []

    for i in np.unique(data['scenario']):
        scaler = CustomScaler()
        target_data = data[data['scenario'] == i].drop(['scenario'], axis=1)
        not_norm_column = ison_list.copy()
        not_norm_column.append('0_behavior')
        target_column = set(target_data.keys()).difference(set(not_norm_column))

        if i in train_scenario:
            train_normalized.append(scaler.fit_transform(target_data, target_column))
            train_scaler.append(scaler)
        elif i in val_scenario:
            val_normalized.append(scaler.fit_transform(target_data, target_column))
            val_scaler.append(scaler)
        elif i in test_scenario:
            test_normalized.append(scaler.fit_transform(target_data, target_column))
            test_scaler.append(scaler)

    train_norm = np.concatenate(train_normalized)
    val_norm = np.concatenate(val_normalized)
    test_norm = np.concatenate(test_normalized)

    return [train_norm, train_scenario, train_scaler], [val_norm, val_scenario, val_scaler], [test_norm, test_scenario,
                                                                                              test_scaler]

def normalize_v2(data, ison_list, train=50, val=5, test=10):
    random_scenario = np.random.permutation(np.unique(data['scenario']))

    train_scenario = random_scenario[:train]
    val_scenario = random_scenario[train:train + val]
    test_scenario = random_scenario[train + val:train + val + test]

    random_scenario = np.random.permutation(np.unique(data['scenario']))

    train_scenario = random_scenario[:train]
    val_scenario = random_scenario[train:train+val]
    test_scenario = random_scenario[train+val:train+val+test]

    train_idx = [np.where(data['scenario'] == each_scenario)[0] for each_scenario in train_scenario]
    train_data = data.iloc[sorted(np.hstack(train_idx))]

    val_idx = [np.where(data['scenario'] == each_scenario)[0] for each_scenario in val_scenario]
    val_data = data.iloc[sorted(np.hstack(val_idx))]

    test_idx = [np.where(data['scenario'] == each_scenario)[0] for each_scenario in test_scenario]
    test_data = data.iloc[sorted(np.hstack(test_idx))]

    not_norm_column = ison_list.copy()
    not_norm_column.append('0_behavior')
    not_norm_column.append('scenario')
    target_column = set(train_data.keys()).difference(set(not_norm_column))
    
    scaler = CustomScaler()
    scaler.fit_transform(train_data, target_column)
    scaler.transform(val_data, target_column)
    scaler.transform(test_data, target_column)

    return [train_data, val_data, test_data], \
           [train_scenario, val_scenario, test_scenario], \
           scaler

def subsys_dataloader(file, flatten, subsys_name):
    data = pd.read_csv(file)
    list_of_scenario, scenario_idx = get_scenario(data)
    data['scenario'] = list_of_scenario

    # 기타변수 제거
    ignore_colums = ['0_environment', '0_target', 'name', 'time', 'timestamp']

    # time 변수 위치 파악 및 제거
    columns = list(data.keys())
    time_list = [each for each in list(data.keys()) if each.find('time') > 0]
    data.drop(ignore_colums + time_list, axis=1, inplace=True)

    # Behavior 카테고리 변환
    behaviors = ['prepare', 'takeoff', 'forward', 'backward', 'up', 'down', 'right', 'left', 'land']
    label_dict = Vocabulary()
    for each_behavior in behaviors:
        label_dict.add_word(each_behavior)
    data['0_behavior'] = data['0_behavior'].map(label_dict.word2idx)

    if len(subsys_name)>1:
        subsys = subsys_name
    else:
        subsys = [subsys_name]
#     subsys = [subsys_name]
    
    data_subsys_list = [data.filter(like=sub) for sub in subsys]
    data_subsys = pd.concat(data_subsys_list, axis=1)
    data_subsys.insert(loc=0, column='0_behavior', value=data['0_behavior'])
    data_subsys.insert(loc=len(data_subsys.columns), column='scenario', value=data['scenario'])
    
#     data_subsys = data
    # Subsystem의 ison 변수 위치 재파악
    ison_list = [each for each in list(data_subsys.keys()) if each.find('ison') > 0]
    ison_dict = {key: np.where(np.array(list(data_subsys.keys())) == key)[0][0] for key in ison_list}
    
    (train_data, val_data, test_data), (train_scenario, val_scenario, test_scenario), scaler = normalize_v2(data_subsys,
                                                                                                            ison_list)

    # 시나리오별 성능 확인용
    train_scenario_index = train_data['scenario']
    val_scenario_index = val_data['scenario']
    test_scenario_index = test_data['scenario']

    X_train, y_train = split_series_v2(train_data.drop(['scenario'], axis=1).values, ison_dict, 10, 1)
    X_val, y_val = split_series_v2(val_data.drop(['scenario'], axis=1).values, ison_dict, 10, 1)
    X_test, y_test = split_series_v2(test_data.drop(['scenario'], axis=1).values, ison_dict, 10, 1)

    X_train_drop = X_train[:, :, 1:]
    X_val_drop = X_val[:, :, 1:]
    X_test_drop = X_test[:, :, 1:]

    print('Training')
    print(f'Scenario: {train_scenario}')
    print(f'Shape of the traninig sample for input: {X_train_drop.shape}')
    print(f'Shape of the traninig sample for label: {y_train.shape}')

    print('\nValidation')
    print(f'Scenario: {val_scenario}')
    print(f'Shape of the traninig sample for input: {X_val_drop.shape}')
    print(f'Shape of the traninig sample for label: {y_val.shape}')

    print('\nTest')
    print(f'Scenario: {test_scenario}')
    print(f'Shape of the traninig sample for input: {X_test_drop.shape}')
    print(f'Shape of the traninig sample for label: {y_test.shape}')

    trainSet = CustomDataset(X_train_drop, y_train, flatten=flatten, which='both')
    valSet = CustomDataset(X_val_drop, y_val, flatten=flatten, which='both')
    testSet = CustomDataset(X_test_drop, y_test, flatten=flatten, which='both')

    train_dataloader = torch.utils.data.DataLoader(trainSet, batch_size=64, shuffle=True, drop_last=True, num_workers=0,
                                                   pin_memory=True)
    val_dataloader = torch.utils.data.DataLoader(valSet, batch_size=64, shuffle=False, drop_last=False, num_workers=0,
                                                 pin_memory=True)
    test_dataloader = torch.utils.data.DataLoader(testSet, batch_size=64, shuffle=True, drop_last=True, num_workers=0,
                                                   pin_memory=True)


    return train_dataloader, val_dataloader, test_dataloader, X_train_drop.shape, y_train.shape, valSet, testSet




def dji_dataloader(file, usecols, flatten):
    
    data = pd.read_csv(file, usecols=usecols)

    data.drop('AAClock', axis=1, inplace=True)

    # Subsystem의 ison 변수 위치 재파악
    ison_list = [each for each in list(data.keys()) if each.find('ison') > 0]
    ison_dict = {key: np.where(np.array(list(data.keys())) == key)[0][0] for key in ison_list}
    print("ison_list:", ison_list)
    print("ison_dict:", ison_dict)

    (train_data, val_data, test_data), (train_scenario, val_scenario, test_scenario), scaler = normalize_v2(data, ison_list, train=20, val=3, test=10)

    # 시나리오별 성능 확인용
    train_scenario_index = train_data['scenario']
    val_scenario_index = val_data['scenario']
    test_scenario_index = test_data['scenario']

    X_train, y_train = split_series_v2(train_data.drop(['scenario'], axis=1).values, ison_dict, 10, 1)
    X_val, y_val = split_series_v2(val_data.drop(['scenario'], axis=1).values, ison_dict, 10, 1)
    X_test, y_test = split_series_v2(test_data.drop(['scenario'], axis=1).values, ison_dict, 10, 1)

    X_train_drop = X_train[:, :, :]
    X_val_drop = X_val[:, :, :]
    X_test_drop = X_test[:, :, :]

    trainSet = CustomDataset(X_train_drop, y_train, flatten=flatten, which='both')
    valSet = CustomDataset(X_val_drop, y_val, flatten=flatten, which='both')
    testSet = CustomDataset(X_test_drop, y_test, flatten=flatten, which='both')

    train_dataloader = torch.utils.data.DataLoader(trainSet, batch_size=64, shuffle=True, drop_last=True, num_workers=0,
                                                   pin_memory=True)
    val_dataloader = torch.utils.data.DataLoader(valSet, batch_size=64, shuffle=False, drop_last=False, num_workers=0,
                                                 pin_memory=True)
    test_dataloader = torch.utils.data.DataLoader(testSet, batch_size=64, shuffle=True, drop_last=True, num_workers=0,
                                                   pin_memory=True)


    res_list = list(train_data.drop(['scenario'], axis=1).columns)
    res_list_ison_out = [each for each in res_list if not each.find('ison')>0]
    res_list_ison_out_dict = {each:idx for idx, each in enumerate(res_list_ison_out)}

    meta = [each.split('.') for each in res_list_ison_out]
    meta_head = np.array([each.split('.')[0] for each in res_list_ison_out])
    super_column = np.unique(meta_head)

    column_idx = {}
    for each_column in super_column:
        column_idx[each_column] = list(np.where(meta_head == each_column)[0])

    return train_dataloader, val_dataloader, test_dataloader, column_idx#, test_data