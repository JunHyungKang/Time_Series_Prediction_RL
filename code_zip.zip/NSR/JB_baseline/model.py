import torch
import torch.nn as nn
import numpy as np
import random

class Stacked(torch.nn.Module):
    def __init__(self,model_type, input_size, hidden_size, output_size, n_layers=4):
        super().__init__()
        self.cell = eval('nn.{}(input_size=input_size, hidden_size=hidden_size, num_layers=n_layers,            bidirectional=True, dropout=0)'.format(model_type))
        
        self.fc = torch.nn.Linear(hidden_size * 2, output_size)

    def forward(self, x):
        x = x.transpose(0, 1)  # (batch, seq, params) -> (seq, batch, params)
        self.cell.flatten_parameters()
        outs, _ = self.cell(x)
        out = self.fc(outs[-1])
        return out
    
class DNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(DNN, self).__init__()
        
        self.linear = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            
            nn.Linear(hidden_size, output_size)
        )
        
    def forward(self, input):
        return self.linear(input)
    
    
    
class Encoder(nn.Module):
    def __init__(self, input_dim=6, hid_dim=64, n_layers=4, model_type='RNN'):
        super().__init__()
        assert model_type in ['RNN','LSTM', 'GRU']
        
        self. hid_dim = hid_dim
        self.n_layers = n_layers
        
        self.cell = eval('nn.{}(input_dim, hid_dim, n_layers, batch_first=True)'.format(model_type))
        
        
    def forward(self, src):
        self.cell.flatten_parameters()
        outputs, hidden = self.cell(src)
        
        
        return outputs, hidden

class DecoderCell(nn.Module):
    def __init__(self, output_dim=6, hid_dim=64, n_layers=4, model_type='RNN'):
        super().__init__()
        assert model_type in ['RNN','LSTM', 'GRU']
        
        self.output_dim = output_dim
        self.hid_dim = hid_dim
        self.n_layers = n_layers
        
        self.cell = eval('nn.{}(hid_dim, hid_dim, n_layers, batch_first=True)'.format(model_type))
        
    def forward(self, x, hidden):
        output, hidden = self.cell(x, hidden)
        
        return output, hidden

class Seq2Seq(nn.Module):
    def __init__(self, input_dim=6, output_dim=6, hid_dim=128, n_layers=4, model_type='RNN', pred_len=10, device='cuda'):
        super().__init__()
        self.device = device
        
        self.pred_len = pred_len
        self.hid_dim = hid_dim

        self.encoder = Encoder(input_dim, hid_dim, n_layers, model_type)
        self.decoder = DecoderCell(output_dim, hid_dim, n_layers, model_type)
        
        self.fc = nn.Linear(hid_dim, output_dim)

        # Encoder와 Decoder의 hidden dim이 같아야 함
        assert self.encoder.hid_dim == self.decoder.hid_dim
        # Encoder와 Decoder의 layer 개수가 같아야 함
        assert self.encoder.n_layers == self.decoder.n_layers
       
    def forward(self, x):
        batch_size = x.shape[0]
        outputs, hidden = self.encoder(x)
        
        de_input = outputs[:, -1, :].unsqueeze(1)
        
        outputs = torch.zeros(batch_size, self.pred_len, self.hid_dim, device=self.device)

        for t in range(self.pred_len):
            output, hidden = self.decoder(de_input, hidden)
            outputs[:, t, :] = output.squeeze(1)
            de_input = output
        
        outputs = self.fc(outputs)
       
        return outputs    
