import os, pickle
import random
import numpy as np
import collections
import tqdm
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as T
from torch.utils.data import DataLoader, Dataset

import plotly.io as pio
pio.renderers.default = 'notebook' # or 'notebook' or 'colab'
import plotly.graph_objects as go

# from subsys.model import *
# from subsys.utils import *
# from subsys.model import Seq2Seq
# from subsys.data_split_subsys import subsys_dataloader

import warnings
warnings.filterwarnings(action='ignore')

from utils import split_series, add_meta, save, train_test_split, get_dataset, CustomDataset, action_step

random_seed = 42
torch.manual_seed(random_seed)
torch.cuda.manual_seed(random_seed)
torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
np.random.seed(random_seed)
random.seed(random_seed)


class DNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(DNN, self).__init__()

        self.linear = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),

            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),

            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),

            nn.Linear(hidden_size, output_size)
        )

    def forward(self, input):
        return self.linear(input)


class Encoder(nn.Module):
    def __init__(self, input_dim=6, hid_dim=64, n_layers=4, model_type='RNN'):
        super().__init__()
        assert model_type in ['RNN', 'LSTM', 'GRU']

        self.hid_dim = hid_dim
        self.n_layers = n_layers

        self.cell = eval('nn.{}(input_dim, hid_dim, n_layers, batch_first=True)'.format(model_type))

    def forward(self, src):
        self.cell.flatten_parameters()
        outputs, hidden = self.cell(src)

        return outputs, hidden


class DecoderCell(nn.Module):
    def __init__(self, output_dim=6, hid_dim=64, n_layers=4, model_type='RNN'):
        super().__init__()
        assert model_type in ['RNN', 'LSTM', 'GRU']

        self.output_dim = output_dim
        self.hid_dim = hid_dim
        self.n_layers = n_layers

        self.cell = eval('nn.{}(hid_dim, hid_dim, n_layers, batch_first=True)'.format(model_type))

    def forward(self, x, hidden):
        output, hidden = self.cell(x, hidden)

        return output, hidden


class Seq2Seq(nn.Module):
    def __init__(self, input_dim=6, output_dim=6, hid_dim=128, n_layers=4, model_type='RNN', pred_len=10,
                 device='cuda'):
        super().__init__()
        self.device = device

        self.pred_len = pred_len
        self.hid_dim = hid_dim

        self.encoder = Encoder(input_dim, hid_dim, n_layers, model_type)
        self.decoder = DecoderCell(output_dim, hid_dim, n_layers, model_type)

        self.fc = nn.Linear(hid_dim, output_dim)

        # Encoder와 Decoder의 hidden dim이 같아야 함
        assert self.encoder.hid_dim == self.decoder.hid_dim
        # Encoder와 Decoder의 layer 개수가 같아야 함
        assert self.encoder.n_layers == self.decoder.n_layers

    def forward(self, x):
        batch_size = x.shape[0]
        outputs, hidden = self.encoder(x)

        de_input = outputs[:, -1, :].unsqueeze(1)

        outputs = torch.zeros(batch_size, self.pred_len, self.hid_dim, device=self.device)

        for t in range(1, self.pred_len):
            output, hidden = self.decoder(de_input, hidden)
            outputs[:, t, :] = output.squeeze(1)
            de_input = output

        outputs = self.fc(outputs)

        return outputs


# class Baseline():
#     def __init__(self, data_path, flight, year, model_name, window_size, pred_len, batch_size):
#         train_months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug' 'Sep', 'Oct', 'Nov']
#         test_months = ['Dec']
#         self.batch_size = batch_size
#         input_seq_len = window_size
#         output_seq_len = pred_len
#         self.pred_len = pred_len
#         self.model_name = model_name
#
#         self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
#         dataset_dict, self.column_name = get_dataset(data_path)
#         # print('self.column_name', self.column_name)
#         self.save_path = '/'.join(['weights', year, flight, self.model_name, str(window_size)])
#         if self.model_name == 'DNN':
#             print('DNN')
#             self.net = DNN(output=output_seq_len, window=window_size).to(self.device)
#         else:
#             print('Seq2Seq ', self.model_name)
#             self.net = Seq2Seq(model_type=self.model_name, pred_len=output_seq_len, device=self.device).to(self.device)
#
#         train_data, test_data, self.s, _ = train_test_split(dataset_dict[flight], train_months, test_months, year, year,
#                                                        norm=True)
#
#         X_train, y_train = np.array(split_series(train_data, input_seq_len, output_seq_len))
#         X_test, y_test = np.array(split_series(test_data, input_seq_len, output_seq_len))
#
#         dataset = CustomDataset(X_train, y_train)
#         trainSet, valSet = torch.utils.data.random_split(dataset,
#                                                          [len(dataset) - int(len(dataset) * 0.3),
#                                                           int(len(dataset) * 0.3)])
#         testSet = CustomDataset(X_test, y_test)
#
#         self.train_dataloader = DataLoader(trainSet, batch_size=self.batch_size, shuffle=True, drop_last=False, num_workers=0)
#         self.val_dataloader = DataLoader(valSet, batch_size=self.batch_size, shuffle=False, drop_last=False, num_workers=0)
#         self.test_dataloader = DataLoader(testSet, batch_size=self.batch_size, shuffle=False, drop_last=True, num_workers=0)
#
#         self.criterionMSE = nn.MSELoss()
#         self.criterionMAE = nn.L1Loss()
#
#         self.best_epoch = 0
#         self.best_mse = 999999
#
#         self.flight = flight
#         self.window_size = window_size
#
#         self.optim = torch.optim.Adam(self.net.parameters(), lr=0.001)
#
#     def train(self, epoch):
#         train_running_step = len(self.train_dataloader)
#         train_mse = 0.0
#         train_mae = 0.0
#
#         self.net.train()
#
#         states = {'train_data': [],
#                   'output': [],
#                   'labels': []}
#
#         for datas, labels in self.train_dataloader:
#             datas = datas.type(torch.FloatTensor).to(self.device)
#             labels = labels.type(torch.FloatTensor).to(self.device)
#
#             self.optim.zero_grad()
#             outputs = self.net(datas)
#
#             loss = self.criterionMSE(outputs, labels)
#             loss.backward()
#             self.optim.step()
#
#             train_mse += loss.item()
#             train_mae += self.criterionMAE(outputs, labels).item()
#
#             states['train_data'].append(datas.cpu())
#             states['output'].append(outputs.cpu())
#             states['labels'].append(labels.cpu())
#
#         train_mse = train_mse / train_running_step
#         train_mae = train_mae / train_running_step
#         print('epoch: {:03d}\ttrain_mse: {:0.6f}\ttrain_mae: {:0.6f}'.format(epoch, train_mse, train_mae))
#
#         return states, train_mse, train_mae
#
#     def valid(self, epoch):
#         val_running_step = len(self.val_dataloader)
#
#         val_mse = 0.0
#         val_mae = 0.0
#
#         self.net.eval()
#
#         states = {'train_data': [],
#                   'output': [],
#                   'labels': []}
#
#         for datas, labels in self.val_dataloader:
#             datas = datas.type(torch.FloatTensor).to(self.device)
#             labels = labels.type(torch.FloatTensor).to(self.device)
#
#             outputs = self.net(datas)
#             val_mse += self.criterionMSE(outputs, labels).item()
#             val_mae += self.criterionMAE(outputs, labels).item()
#
#             states['train_data'].append(datas.cpu())
#             states['output'].append(outputs.cpu())
#             states['labels'].append(labels.cpu())
#
#         val_mse = val_mse / val_running_step
#         val_mae = val_mae / val_running_step
#
#         save('last', epoch, self.save_path, self.model_name, self.net)
#         if val_mse < self.best_mse:
#             save('best', epoch, self.save_path, self.model_name, self.net)
#             self.best_mse = val_mse
#             self.best_epoch = epoch
#
#         print('epoch: {:03d}\tvalid_mse: {:0.6f}\tvalid_mae: {:0.6f}'.format(epoch, val_mse, val_mae))
#         print('best_epoch: {}'.format(self.best_epoch))
#
#         return states, val_mse, val_mae
#
#     def test(self):
#         meta = torch.load(os.path.join(self.save_path, self.model_name + '_best.path.tar'))
#         self.net.load_state_dict(meta['model_state_dict'])
#
#         test_mse = 0.0
#         test_mae = 0.0
#
#         test_mse_rescaled = 0.0
#         test_mae_rescaled = 0.0
#
#         states = {'train_data': [],
#                   'output': [],
#                   'labels': []}
#
#         test_running_step = len(self.test_dataloader)
#         self.net.eval()
#         for datas, labels in self.test_dataloader:
#             datas = datas.type(torch.FloatTensor).to(self.device)
#             labels = labels.type(torch.FloatTensor).to(self.device)
#
#             outputs = self.net(datas)
#
#             states['train_data'].append(datas.cpu())
#             states['output'].append(outputs.cpu())
#             states['labels'].append(labels.cpu())
#
#             test_mse += self.criterionMSE(outputs, labels).item()
#             test_mae += self.criterionMAE(outputs, labels).item()
#
#             outputs_np = outputs.cpu().detach().numpy()
#             labels_np = labels.cpu().detach().numpy()
#
#             for i, out in enumerate(outputs_np):
#                 out_r = self.s.inverse_transform(out)
#                 if i == 0:
#                     outputs_np = out_r
#                 else:
#                     outputs_np = np.append(outputs_np, out_r, axis=0)
#             for i, lab in enumerate(labels_np):
#                 lab_r = self.s.inverse_transform(lab)
#
#                 if i == 0:
#                     labels_np = lab_r
#                 else:
#                     labels_np = np.append(labels_np, lab_r, axis=0)
#
#             outputs_np = torch.tensor(outputs_np.reshape((self.batch_size, self.pred_len, len(self.column_name))))
#             labels_np = torch.tensor(labels_np.reshape((self.batch_size, self.pred_len, len(self.column_name))))
#
#             test_mse_rescaled += self.criterionMSE(outputs_np, labels_np).item()
#             test_mae_rescaled += self.criterionMAE(outputs_np, labels_np).item()
#
#         test_mse = test_mse / test_running_step
#         test_mae = test_mae / test_running_step
#         rescaled_test_mse = test_mse_rescaled / test_running_step
#         rescaled_test_mae = test_mae_rescaled / test_running_step
#         print(self.flight, self.model_name, self.window_size)
#         print(f'\t test mse/mae: {test_mse:<.5}/{test_mae:<.5}')
#         print(f'\t rescaled test mse/mae: {rescaled_test_mse:<.5}/{rescaled_test_mae:<.5}\n')
#
#         return states, test_mse, test_mae


class Baseline():
    def __init__(self, tr_loader, val_loader, test_loader, x_shape, y_shape, valSet, testSet,
                 subsys, model, save_path, lr, writer):
        self.subsys = subsys
        self.train_dataloader, self.val_dataloader, self.test_dataloader, x_shape, y_shape, self.valSet, self.testSet \
            = tr_loader, val_loader, test_loader, x_shape, y_shape, valSet, testSet

        IN_FEAT = x_shape[-1]
        OUT_FEAT = y_shape[-1] + 8
        IN_SEQ = 10
        OUT_SEQ = 1
        self.SAVE_PATH = save_path
        self.writer = writer

        models = {'DNN': DNN, 'RNN': 'RNN'}
        self.model_name = model

        if self.model_name == 'DNN':
            self.model = models[model](input_size=IN_FEAT * IN_SEQ, hidden_size=128, output_size=OUT_FEAT * OUT_SEQ)
        elif self.model_name == 'RNN':
            self.model = Seq2Seq(input_dim=IN_FEAT, output_dim=OUT_FEAT, model_type=model, pred_len=1)

        self.model.cuda()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
        self.criterionMSE = nn.MSELoss()
        self.criterionCE = nn.CrossEntropyLoss()

        self.best_val_total = np.inf

        scaler = torch.cuda.amp.GradScaler()

    def train(self, epoch, loss_weight):
        train_running_step = len(self.train_dataloader)
        self.model.train()

        train_mse = 0
        train_ce = 0
        train_total = 0
        loss_weights = {'2_8': (0.2, 0.8), '4_6': (0.4, 0.6), '5_5': (0.5, 0.5), '6_4': (0.6, 0.4), '8_2': (0.8, 0.2)}
        alpha, beta = loss_weights[loss_weight]
        states = {'train_data': [],
                  'output': [],
                  'labels': []}
        total_rl_mse = []
        for train_idx, (inputs, labels, rl_data) in enumerate(self.train_dataloader):
            rl_mse = []
            inputs = inputs.cuda()

            if self.model_name == 'DNN':
                labels_state = labels[:, 1:].cuda()
                labels_behavior = labels[:, 0].type(torch.LongTensor).cuda()
            else:
                labels_state = labels[:, :, 1:].cuda()
                labels_behavior = labels[:, :, 0].type(torch.LongTensor).cuda()

            self.optimizer.zero_grad()

            with torch.cuda.amp.autocast():
                outputs = self.model(inputs)

                if self.model_name == 'DNN':
                    loss_mse = self.criterionMSE(outputs[:, :-9], labels_state)  # 기체 상태 MSE 예측
                    loss_ce = self.criterionCE(outputs[:, -9:], labels_behavior)  # behavior 확률 변수
                    for i in range(len(labels_state)):
                        rl_mse.append(self.criterionMSE(outputs[i, :-9], labels_state[i]).item())

                else:
                    loss_mse = self.criterionMSE(outputs[:, :, :-9], labels_state)
                    loss_ce = self.criterionCE(outputs[:, :, -9:].squeeze(1), labels_behavior.squeeze(1))
                    for i in range(len(labels_state)):
                        rl_mse.append(self.criterionMSE(outputs[i, :, :-9], labels_state[i]).item())

                loss = alpha*loss_mse + beta*loss_ce

            total_rl_mse.append(rl_mse)
            states['train_data'].append(rl_data.cpu())
            states['output'].append(outputs[:, :-9].cpu())
            states['labels'].append(labels_state.cpu())

            loss.backward()
            self.optimizer.step()

            train_mse += loss_mse.item()
            train_ce += loss_ce.item()
            train_total += loss.item()

        train_mse = train_mse / train_running_step
        train_ce = train_ce / train_running_step
        train_total = train_total / train_running_step
        print('\nepoch: {}\tsubsys: {}'.format(epoch, self.subsys))
        print('train MSE: {}'.format(train_mse))
        print('train CE: {}'.format(train_ce))
        print('train TOTAL: {}'.format(train_total))
        self.writer.add_scalar("Train/MSE", train_mse, epoch)
        self.writer.add_scalar("Train/CE", train_ce, epoch)
        self.writer.add_scalar("Train/TOTAL", train_total, epoch)

        return states, total_rl_mse, train_mse

    def valid(self, epoch):
        # validation Procedure
        val_running_step = len(self.val_dataloader)

        self.model.eval()
        val_mse = 0
        val_ce = 0
        val_total = 0
        val_acc = 0
        with torch.no_grad():
            states = {'train_data': [],
                      'output': [],
                      'labels': []}
            total_rl_mse = []
            for val_idx, (inputs, labels, rl_data) in enumerate(self.val_dataloader):
                rl_mse = []
                inputs = inputs.cuda()
                if self.model_name == 'DNN':
                    labels_state = labels[:, 1:].cuda()
                    labels_behavior = labels[:, 0].type(torch.LongTensor).cuda()
                else:
                    labels_state = labels[:, :, 1:].cuda()
                    labels_behavior = labels[:, :, 0].type(torch.LongTensor).cuda()

                outputs = self.model(inputs)

                if self.model_name == 'DNN':
                    loss_mse = self.criterionMSE(outputs[:, :-9], labels_state)  # 기체 상태 MSE 예측
                    loss_ce = self.criterionCE(outputs[:, -9:], labels_behavior)  # behavior 확률 변수
                    for i in range(len(labels_state)):
                        rl_mse.append(self.criterionMSE(outputs[i, :-9], labels_state[i]).item())
                else:
                    loss_mse = self.criterionMSE(outputs[:, :, :-9], labels_state)
                    loss_ce = self.criterionCE(outputs[:, :, -9:].squeeze(1), labels_behavior.squeeze(1))
                    for i in range(len(labels_state)):
                        rl_mse.append(self.criterionMSE(outputs[i, :, :-9], labels_state[i]).item())

                total_rl_mse.append(rl_mse)
                states['train_data'].append(rl_data.cpu())
                states['output'].append(outputs[:, :-9].cpu())
                states['labels'].append(labels_state.cpu())

                val_mse += loss_mse.item()
                val_ce += loss_ce.item()
                val_total += val_ce + val_mse
                val_acc += (outputs[:, -9:].argmax(axis=1) == labels_behavior).sum().item()

        val_mse = val_mse / val_running_step
        val_ce = val_ce / val_running_step
        val_total = val_total / val_running_step
        val_acc = val_acc / len(self.valSet)
        print('val MSE: {}'.format(val_mse))
        print('val CE: {}'.format(val_ce))
        print('val TOTAL: {}'.format(val_total))
        print('val ACC: {}'.format(val_acc))
        self.writer.add_scalar("MSE/Val", val_mse, epoch)
        self.writer.add_scalar("CE/Val", val_ce, epoch)
        self.writer.add_scalar("TOTAL/Val", val_total, epoch)
        self.writer.add_scalar("ACC/Val", val_acc, epoch)

        if val_total < self.best_val_total:
            print(f'\t Best val total changed [{round(self.best_val_total, 5)} ---> {round(val_total, 5)}]')
            save('best', epoch, self.SAVE_PATH, self.model_name, self.model, None)
            self.best_val_total = val_total

        return states, total_rl_mse, val_mse

    def test(self):
        test_running_step = len(self.test_dataloader)

        test_model = self.model

        if os.path.isfile(self.SAVE_PATH + '/' + self.model_name + '_best.path.tar'):
            meta = torch.load(self.SAVE_PATH + '/' + self.model_name + '_best.path.tar')
            test_model.load_state_dict(meta['model_state_dict'])

            test_model.cuda()
            test_model.eval()

            test_mse = 0
            test_ce = 0
            test_total = 0
            test_acc = 0

            with torch.no_grad():
                for test_idx, (inputs, labels) in enumerate(self.test_dataloader):
                    inputs = inputs.cuda()
                    if self.model_name == 'DNN':
                        labels_state = labels[:, 1:].cuda()
                        labels_behavior = labels[:, 0].type(torch.LongTensor).cuda()
                    else:
                        labels_state = labels[:, :, 1:].cuda()
                        labels_behavior = labels[:, :, 0].type(torch.LongTensor).cuda()

                    outputs = self.model(inputs)

                    if self.model_name == 'DNN':
                        loss_mse = self.criterionMSE(outputs[:, :-9], labels_state)  # 기체 상태 MSE 예측
                        loss_ce = self.criterionCE(outputs[:, -9:], labels_behavior)  # behavior 확률 변수
                    else:
                        loss_mse = self.criterionMSE(outputs[:, :, :-9], labels_state)
                        loss_ce = self.criterionCE(outputs[:, :, -9:].squeeze(1), labels_behavior.squeeze(1))

                    test_mse += loss_mse.item()
                    test_ce += loss_ce.item()
                    test_total += test_ce + test_mse
                    test_acc += (outputs[:, -9:].argmax(axis=1) == labels_behavior).sum().item()

            test_mse = test_mse / test_running_step
            test_ce = test_ce / test_running_step
            test_total = test_total / test_running_step
            test_acc = test_acc / len(self.testSet)

            self.writer.add_scalar("MSE/Test", test_mse, epoch)
            self.writer.add_scalar("CE/Test", test_ce, epoch)
            self.writer.add_scalar("TOTAL/Test", test_total, epoch)
            self.writer.add_scalar("ACC/Test", test_acc, epoch)

            print('test MSE: {}'.format(test_mse))
            print('test CE: {}'.format(test_ce))
            print('test TOTAL: {}'.format(test_total))
            print('test ACC: {}'.format(test_acc))


class ReplayBuffer:
    def __init__(self, buffer_limit):
        self.buffer = collections.deque(maxlen=buffer_limit)

    def put(self, transition):
        self.buffer.append(transition)

    def sample(self, n):
        mini_batch = random.sample(self.buffer, n)
        s_lst, a_lst, r_lst, s_prime_lst, done_mask_lst = [], [], [], [], []

        for transition in mini_batch:
            s, a, r, s_prime, done_mask = transition
            s_lst.append(s)
            a_lst.append(a.tolist())
            r_lst.append([r])
            s_prime_lst.append(s_prime)
            done_mask_lst.append([done_mask])

        return torch.tensor(s_lst, dtype=torch.float), torch.tensor(a_lst, dtype=torch.int64), \
               torch.tensor(r_lst), torch.tensor(s_prime_lst, dtype=torch.float), \
               torch.tensor(done_mask_lst)

    def size(self):
        return len(self.buffer)


class Qnet(nn.Module):
    def __init__(self, x_shape):
        super(Qnet, self).__init__()
        self.input_size = (x_shape[-1]-1) * 11
        self.fc1 = nn.Linear(self.input_size, 512)
        self.fc2 = nn.Linear(512, 512)
        self.fc3 = nn.Linear(512, 256)
        self.fc4 = nn.Linear(256, (x_shape[-1]-1)*3)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        x = F.sigmoid(self.fc4(x))
        return x

    def sample_action(self, obs, epsilon, writer, count):
        obs = obs.reshape((-1, self.input_size))  # (1, (window_size+prediction length)*features)
        out = self.forward(obs)  # shape: (1, actions * prediction length = 3*10 = 30)
        actions = out.detach().numpy()

        rand_coin = np.random.rand(out.shape[0], int(out.shape[1]/3))  # (batchsize, 6)
        new_actions = torch.zeros(actions.shape)

        act_dict = {'0': 0, '1': 0, '2': 0}

        # print('actions.shape', actions.shape)
        # TODO: Numpy 연산 최적화 시키기
        for iter in range(actions.shape[0]):
            for i in range(int(out.shape[1]/3)):
                if rand_coin[iter][i] < epsilon:
                    acting = random.randint(0, 2)
                    new_actions[iter][(i*3)+acting] = 1
                    act_dict[str(acting)] += 1
                else:
                    max_ind = actions[iter][i*3:(i*3)+3].argmax()
                    new_actions[iter][(i*3) + max_ind] = 1
                    act_dict[str(max_ind)] += 1

        if writer is not None:
            writer.add_scalars('Action/Sample', {'up': act_dict['0'],
                                                 'keep': act_dict['1'],
                                                 'down': act_dict['2']},
                               count)
        return new_actions

    def max_action(self, obs):
        obs = obs.reshape((-1, self.input_size))
        out = self.forward(obs)
        actions = out.detach().numpy()
        new_actions = torch.zeros(actions.shape)

        act_dict = {'0': 0, '1': 0, '2': 0}

        for iter in range(actions.shape[0]):
            for i in range(int(out.shape[1] / 3)):
                max_ind = actions[iter][i*3:(i*3)+3].argmax()
                new_actions[iter][(i*3) + max_ind] = 1
                act_dict[str(max_ind)] += 1

        return new_actions


class Qlearning():
    def __init__(self, q, q_target, memory, optimizer, hyperparameters, writer):
        self.q = q
        self.q_target = q_target
        self.memory = memory
        self.optimizer = optimizer
        self.hyperparameters = hyperparameters
        self.writer = writer
        # self.window_size = window_size
        self.simul_action_count = 0
        self.valid_loss_count = 0
        # self.target_feature = target_feature
        # self.pred_len = pred_len
        self.batch_size = self.hyperparameters['batch_size']

    def adding_memory(self, datas, train_mse, epsilon, epoch):
        avg_score = 0.0
        avg_count = 0
        memory_count = 0
        time.sleep(0.5)

        for i in tqdm.tqdm(range(len(datas['train_data'])), desc='Adding memory'):
            for j in range(len(datas['train_data'][i])):
                score = 0.0

                data = datas['train_data'][i][j].clone().detach().numpy()
                output = datas['output'][i][j].clone().detach().numpy()
                labels = datas['labels'][i][j].clone().detach().numpy()
                initial_mse = train_mse[i][j]

                data = data.reshape((10, output.shape[-1]))
                output = output.reshape((1, output.shape[-1]))
                labels = labels.reshape((1, output.shape[-1]))
                state = np.concatenate((data, output), axis=0)
                done = False

                count = 1
                while not done:
                    actions = self.q.sample_action(torch.from_numpy(state).float(), epsilon, self.writer,
                                                   self.simul_action_count)
                    self.simul_action_count += 1
                    next_state, reward, new_mse, _ = action_step(state, actions, labels, initial_mse,
                                                                 self.hyperparameters['action_size'])
                    if count > 5:
                        done = True
                    done_mask = 0.0 if done else 1.0
                    count += 1

                    self.memory.put((state, actions, reward, next_state, done_mask))

                    state = next_state
                    initial_mse = new_mse

                    score += reward
                self.writer.add_scalar('RL_Memory/Score', score, self.simul_action_count)
                self.writer.add_scalar('RL_Memory/Count', count, self.simul_action_count)

                avg_score += score
                avg_count += count
                memory_count += 1

                break

        self.writer.add_scalar('RL_Memory/Avg_Score', avg_score / memory_count, epoch)
        self.writer.add_scalar('RL_Memory/Avg_Count', avg_count / memory_count, epoch)

    def train(self, epoch):
        train_step = self.hyperparameters['train_step']
        rl_gamma = self.hyperparameters['gamma']
        total_loss = 0.0
        for _ in tqdm.tqdm(range(train_step), desc='RL training'):
            time.sleep(0.01)
            s, a, r, s_prime, done_mask = self.memory.sample(self.batch_size)
            print('s.shape', s.shape)
            print('a.shape', a.shape)
            print('r.shape', r.shape)
            print('s_prime.shape', s_prime.shape)
            print('done_mask.shape', done_mask.shape)
            s = s.reshape((self.batch_size, -1))
            q_out = self.q(s)
            q_a = q_out * a.squeeze()
            s_prime = s_prime.reshape((self.batch_size, -1))
            max_q_prime = self.q_target(s_prime) * self.q_target.max_action(s_prime).squeeze()
            target = r + rl_gamma * max_q_prime * done_mask
            loss = F.smooth_l1_loss(q_a, target)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            total_loss += loss
        self.q_target.load_state_dict(self.q.state_dict())
        self.writer.add_scalar('RL_Train/Avg_Loss', total_loss/train_step, epoch)

    def valid(self, datas, val_mse, epoch):
        self.q.eval()
        refined_val_mse = 0
        refined_val_mae = 0
        count = 0
        avg_score = 0
        avg_count = 0

        for i in tqdm.tqdm(range(len(datas['train_data'])), desc='Calculating Refined Prediction'):
            data = datas['train_data'][i].clone().detach().numpy()
            output = datas['output'][i].clone().detach().numpy()
            labels = datas['labels'][i].clone().detach().numpy()
            state = np.concatenate((data, output), axis=1)

            action = self.q.sample_action(torch.tensor(state.reshape((self.batch_size, -1))), 0, None, None)

            for j in range(len(action)):
                iter = 0
                score = 0
                done = False
                initial_state = state[j]
                initial_action = action[j]
                while not done:
                    print('val function - initial_state.shape', initial_state.shape)
                    next_state, reward, new_mse, _ = action_step(initial_state.reshape((1, -1)), initial_action.reshape((1, -1)),
                                                                 labels[j], val_mse,
                                                                 self.hyperparameters['action_size'])

                    initial_state = next_state
                    initial_action = self.q.sample_action(
                        torch.tensor(initial_state.reshape((self.batch_size, -1))), 0, None, None)

                    iter += 1
                    score += reward
                    val_mse = new_mse

                    if iter > 9:
                        done = True

                refined_val_mse += val_mse
                count += 1
                avg_score += score
                avg_count += iter

                if epoch != 999:
                    self.valid_loss_count += 1
                    self.writer.add_scalar('RL_valid/Count', iter, self.valid_loss_count)
                    self.writer.add_scalar('RL_valid/Score', score, self.valid_loss_count)

        if epoch != 999:
            self.writer.add_scalar('RL_valid/refinement avg score', avg_score / count, epoch)
            self.writer.add_scalar('RL_valid/refinement avg score', avg_count / count, epoch)

        refined_val_mse = refined_val_mse / count
        refined_val_mae = refined_val_mae / count

        print('epoch: {:03d}\trefined_mse: {:0.6f}\trefined_mae: {:0.6f}'.format(epoch, refined_val_mse, refined_val_mae))

        return refined_val_mse, refined_val_mae

