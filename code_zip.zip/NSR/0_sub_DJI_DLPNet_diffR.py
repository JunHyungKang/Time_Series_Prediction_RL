import os, random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from glob import glob
from tqdm import tqdm, trange

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter
from torch.distributions.categorical import Categorical
from torch.distributions.normal import Normal
from torch.optim import Adam

import torchvision.models as torchmodels

from sklearn.preprocessing import MinMaxScaler, LabelEncoder

from JB_baseline.model import *
from JB_baseline.utils import *
from total_utils import get_sub_data

import warnings
warnings.filterwarnings(action='ignore')


class Baseline:
    def __init__(self, model_type, hid_dim, n_layers, window_size, pred_len, schedule, X_train, y_train, X_val,
                 y_val, X_test, y_test, column_idx, seed_item, grid_item, batch_size):
        IN_FEAT = X_train.shape[-1]
        OUT_FEAT = y_train.shape[-1]
        IN_SEQ = window_size
        OUT_SEQ = pred_len
        self.column_idx = column_idx
        self.schedule = schedule

        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        # self.device = 'cpu'
        self.model_type = model_type

        if self.model_type == 'DNN':
            flatten = True
            self.model = \
                DNN(input_size=IN_FEAT * IN_SEQ, hidden_size=hid_dim, output_size=OUT_FEAT * OUT_SEQ).to(self.device)
        else:
            flatten = False
            if self.model_type[:7] == 'Stacked':
                self.model = Stacked(self.model_type[7:], IN_FEAT, hid_dim, OUT_FEAT, 4).to(self.device)
            elif self.model_type[:7] == 'Seq2Seq':
                self.model = Seq2Seq(input_dim=IN_FEAT, output_dim=OUT_FEAT, hid_dim=hid_dim, n_layers=n_layers,
                                     model_type=self.model_type[8:], pred_len=OUT_SEQ).to(self.device)
            else:
                self.model = \
                    eval('nn.{}(IN_FEAT, OUT_FEAT, n_layers, batch_first=True).to(device)'.format(self.model_type))

        trainSet = CustomDataset(X_train, y_train, flatten=flatten)
        valSet = CustomDataset(X_val, y_val, flatten=flatten)
        testSet = CustomDataset(X_test, y_test, flatten=flatten)
        self.len_val = len(valSet)
        self.len_test = len(testSet)

        self.train_dataloader = torch.utils.data.DataLoader(trainSet, batch_size=batch_size, shuffle=True, drop_last=True,
                                                            num_workers=0, pin_memory=False)
        self.val_dataloader = torch.utils.data.DataLoader(valSet, batch_size=batch_size, shuffle=False, drop_last=False,
                                                          num_workers=0, pin_memory=False)
        self.test_dataloader = torch.utils.data.DataLoader(testSet, batch_size=batch_size, shuffle=False, drop_last=False,
                                                           num_workers=0, pin_memory=False)

        self.SAVE_PATH = os.path.join('weights', '_'.join(['origin_px4_newR', str(seed_item), str(grid_item[0]), self.model_type,
                                                           str(window_size), str(pred_len), str(hid_dim),
                                                           str(n_layers)]))

        os.makedirs(self.SAVE_PATH, exist_ok=True)

        self.scaler = torch.cuda.amp.GradScaler()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-3)
        self.criterionMSE = nn.MSELoss()
        self.criterionMAE = nn.L1Loss()
        self.criterionCE = nn.CrossEntropyLoss()

        print('train path: ', self.SAVE_PATH + '/res.csv')
        if self.schedule:
            self.scheduler = torch.optim.lr_scheduler.MultiStepLR(self.optimizer, milestones=[40], gamma=0.1)

        self.writer = SummaryWriter(self.SAVE_PATH + '/tb_log')

        self.best_total = np.inf
        self.best_epoch = 0
        self.rate = rate

    def train(self, epoch):
        train_running_step = len(self.train_dataloader)

        self.model.train()
        train_mse = 0
        train_mae = 0
        train_total = 0

        for train_idx, (inputs, labels, rl_inputs, rl_labels) in enumerate(self.train_dataloader):
            inputs = inputs.to(self.device)
            labels_state = labels.to(self.device)

            self.optimizer.zero_grad()
            with torch.cuda.amp.autocast():
                outputs = self.model(inputs)

                if self.model_type in ['RNN', 'LSTM', 'GRU']:
                    outputs = outputs[0][:, -1, :].unsqueeze(1)

                if self.model_type == 'DNN':
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)
                else:
                    if self.model_type[:7] == 'Stacked':
                        outputs = outputs.unsqueeze(1)
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)

                loss = grid_item[0]*loss_mse + grid_item[1]*loss_mae

            loss.backward()
            self.optimizer.step()

            train_mse += loss_mse.item()
            train_mae += loss_mae.item()
            train_total += loss.item()

        train_mse = train_mse / train_running_step
        train_mae = train_mae / train_running_step
        train_total = train_total / train_running_step

        print('\nepoch: {}'.format(epoch))
        print('train MSE: {}'.format(train_mse))
        print('train MAE: {}'.format(train_mae))
        print('train TOTAL: {}'.format(train_total))
        self.writer.add_scalar("Train/MSE", train_mse, epoch)
        self.writer.add_scalar("Train/MAE", train_mae, epoch)
        self.writer.add_scalar("Train/TOTAL", train_total, epoch)

    def valid(self, epoch):
        val_running_step = len(self.val_dataloader)

        self.model.eval()
        val_mse = 0
        val_mae = 0
        val_total = 0

        with torch.no_grad():
            for val_idx, (inputs, labels, _, _) in enumerate(self.val_dataloader):
                inputs = inputs.to(self.device)
                labels_state = labels.to(self.device)

                outputs = self.model(inputs)
                if self.model_type in ['RNN', 'LSTM', 'GRU']:
                    outputs = outputs[0][:, -1, :].unsqueeze(1)
                if self.model_type == 'DNN':
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)
                else:
                    if self.model_type[:7] == 'Stacked':
                        outputs = outputs.unsqueeze(1)
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)

                loss = grid_item[0] * loss_mse + grid_item[1] * loss_mae

                val_mse += loss_mse.item()
                val_mae += loss_mae.item()
                val_total += loss.item()

        val_mse = val_mse / val_running_step
        val_mae = val_mae / val_running_step
        val_total = val_total / val_running_step

        print('val MSE: {}'.format(val_mse))
        print('val MAE: {}'.format(val_mae))
        print('val TOTAL: {}'.format(val_total))
        self.writer.add_scalar("Val/MSE", val_mse, epoch)
        self.writer.add_scalar("Val/MAE", val_mae, epoch)
        self.writer.add_scalar("Val/TOTAL", val_total, epoch)

        if val_total < self.best_total:
            self.best_epoch = epoch
            save('best', epoch, self.SAVE_PATH, self.model, self.optimizer)
            self.best_total = val_total
        save('last', epoch, self.SAVE_PATH, self.model, self.optimizer)

        if self.schedule:
            self.scheduler.step()

    def test(self):
        self.model.load_state_dict(torch.load(os.path.join(self.SAVE_PATH, 'best.path.tar'))['model_state_dict'])
        self.model.eval();

        mse = []

        with torch.no_grad():
            for inputs, labels, _, _ in self.test_dataloader:
                inputs = inputs.to(self.device)
                labels_state = labels.to(self.device)
                outputs = self.model(inputs)

                if self.model_type in ['RNN', 'LSTM', 'GRU']:
                    outputs = outputs[0][:, -1, :].unsqueeze(1)
                outputs = outputs.squeeze(1)
                mse.extend(((outputs - labels_state.squeeze(1)) ** 2).detach().cpu().numpy())

        mse = np.array(mse).mean(axis=0)

        results = {}
        for idx in self.column_idx:
            results[idx] = mse[self.column_idx[idx]].mean()

        results['average'] = sum(results.values())/len(list(results.values()))
        results_df = pd.DataFrame.from_dict([results])
        results_df.to_csv(os.path.join(self.SAVE_PATH, 'test.csv'), index=False)
        print('test save path: ', os.path.join(self.SAVE_PATH, 'test.csv'))
        print('\n####################################################################\n')


class Baseline_RL:
    def __init__(self, model_type, hid_dim, n_layers, window_size, pred_len, schedule, X_train, y_train, X_val,
                 y_val, X_test, y_test, column_idx, rate, seed_item, rl_lr_item, rate_item, batch_size):
        IN_FEAT = X_train.shape[-1]
        OUT_FEAT = y_train.shape[-1]
        IN_SEQ = window_size
        OUT_SEQ = pred_len
        self.column_idx = column_idx
        self.schedule = schedule
        self.rate = rate
        self.DLPNet = DLPNet(IN_FEAT, IN_SEQ, self.rate)

        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model_type = model_type

        if self.model_type == 'DNN':
            flatten = True
            self.model = \
                DNN(input_size=IN_FEAT * IN_SEQ, hidden_size=hid_dim, output_size=OUT_FEAT * OUT_SEQ).to(self.device)
        else:
            flatten = False
            if self.model_type[:7] == 'Stacked':
                self.model = Stacked(self.model_type[7:], IN_FEAT, hid_dim, OUT_FEAT, 4).to(self.device)
            elif self.model_type[:7] == 'Seq2Seq':
                self.model = Seq2Seq(input_dim=IN_FEAT, output_dim=OUT_FEAT, hid_dim=hid_dim, n_layers=n_layers,
                                     model_type=self.model_type[8:], pred_len=OUT_SEQ).to(self.device)
            else:
                self.model = \
                    eval('nn.{}(IN_FEAT, OUT_FEAT, n_layers, batch_first=True).to(device)'.format(self.model_type))

        trainSet = CustomDataset(X_train, y_train, flatten=flatten)
        valSet = CustomDataset(X_val, y_val, flatten=flatten)
        testSet = CustomDataset(X_test, y_test, flatten=flatten)
        self.len_val = len(valSet)
        self.len_test = len(testSet)

        self.train_dataloader = torch.utils.data.DataLoader(trainSet, batch_size=batch_size, shuffle=True, drop_last=True,
                                                            num_workers=0, pin_memory=False)
        self.val_dataloader = torch.utils.data.DataLoader(valSet, batch_size=batch_size, shuffle=False, drop_last=False,
                                                          num_workers=0, pin_memory=False)
        self.test_dataloader = torch.utils.data.DataLoader(testSet, batch_size=batch_size, shuffle=False, drop_last=False,
                                                           num_workers=0, pin_memory=False)

        self.SAVE_PATH = os.path.join('weights', '_'.join(['rl_dji_diffR', str(seed_item), str(rl_lr_item), str(rate_item), self.model_type, str(window_size), str(pred_len),
                                                           str(hid_dim), str(n_layers)]))

        if self.schedule:
            self.SAVE_PATH = os.path.join(['weights', 'scheculer', '_'.join([self.model_type, window_size, pred_len])])
        os.makedirs(self.SAVE_PATH, exist_ok=True)

        self.scaler = torch.cuda.amp.GradScaler()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-3)
        self.optimizer_rl = torch.optim.Adam(self.DLPNet.agent.parameters(), lr=rl_lr_item)
        self.scheduler_rl = torch.optim.lr_scheduler.ExponentialLR(self.optimizer_rl, gamma=0.96, last_epoch=-1)
        self.criterionMSE = nn.MSELoss()
        self.criterionMAE = nn.L1Loss()
        self.criterionCE = nn.CrossEntropyLoss()

        print('train path: ', self.SAVE_PATH + '/res.csv')
        if self.schedule:
            self.scheduler = torch.optim.lr_scheduler.MultiStepLR(self.optimizer, milestones=[40], gamma=0.1)

        self.writer = SummaryWriter(self.SAVE_PATH + '/tb_log')

        self.best_total = np.inf
        self.best_epoch = 0


    def train(self, epoch):
        train_running_step = len(self.train_dataloader)

        self.model.train()
        self.DLPNet.agent.train()

        train_mse = 0
        train_mae = 0
        train_total = 0
        rews = []
        ep_logp = []
        acts = []

        self.optimizer_rl.zero_grad()
        for train_idx, (inputs, labels, rl_inputs, rl_labels) in enumerate(self.train_dataloader):
            inputs = inputs.to(self.device)
            rl_inputs = rl_inputs.to(self.device)
            labels_state = labels.to(self.device)

            self.optimizer.zero_grad()
            with torch.cuda.amp.autocast():
                outputs = self.model(inputs)
                act = self.DLPNet.get_action(rl_inputs)
                acts.extend(act.detach().cpu().tolist())
                para_list = self.DLPNet.get_parameter(act)

                if self.model_type in ['RNN', 'LSTM', 'GRU']:
                    outputs = outputs[0][:, -1, :].unsqueeze(1)

                if self.model_type == 'DNN':
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)
                else:
                    if self.model_type[:7] == 'Stacked':
                        outputs = outputs.unsqueeze(1)
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)

                origin_loss = loss_mse + loss_mae
                new_loss_mse = sum(torch.tensor(para_list).to(self.device)[:, 0] * loss_mse)
                new_loss_mae = sum(torch.tensor(para_list).to(self.device)[:, 1] * loss_mae)
                new_loss = new_loss_mse + new_loss_mae

            new_loss.backward()

            self.model.eval()
            if self.model_type == 'DNN':
                rew_mse = self.criterionMSE(self.model(inputs), labels_state)
                rew_mae = self.criterionMAE(self.model(inputs), labels_state)
                rew = origin_loss - (rew_mse + rew_mae)
            else:
                rew_mse = self.criterionMSE(self.model(inputs).unsqueeze(1), labels_state)
                rew_mae = self.criterionMAE(self.model(inputs).unsqueeze(1), labels_state)
                rew = (origin_loss - (rew_mse + rew_mae)) * 10
            self.model.train()

            rews.append(rew.detach().cpu().item())
            self.optimizer.step()

            batch_logp = self.DLPNet.compute_logp(rl_inputs, act)
            ep_logp.append(sum(batch_logp.cpu().tolist()))

            train_mse += new_loss_mse.item()
            train_mae += new_loss_mae.item()
            train_total += new_loss.item()

        train_mse = train_mse / train_running_step
        train_mae = train_mae / train_running_step
        train_total = train_total / train_running_step

        ep_ret = sum(rews)
        ep_weights = list(self.DLPNet.reward_to_go(rews))
        mean = np.mean(ep_weights)
        std = np.std(ep_weights)
        ep_weights = (ep_weights - mean) / std
        rl_loss = self.DLPNet.compute_loss(logp=torch.as_tensor(ep_logp),
                                           weights=torch.as_tensor(ep_weights))
        rl_loss.requires_grad = True
        rl_loss.backward()

        self.optimizer_rl.step()

        epoch_loss = train_total / len(self.train_dataloader)
        print('loss: {}'.format(epoch_loss))
        print('RL loss: {}'.format(rl_loss))
        print('RL return: {}'.format(ep_ret))
        self.writer.add_scalar("RL/loss", rl_loss, epoch)
        self.writer.add_scalar("RL/return", ep_ret, epoch)

        for i in range(5):
            print('action count for {}: {}'.format(i, acts.count(i)))

        self.writer.add_scalars("Action", {'0': acts.count(0), '1': acts.count(1), '2': acts.count(2),
                                           '3': acts.count(3), '4': acts.count(4)}, epoch)

        print('\nepoch: {}'.format(epoch))
        print('train MSE: {}'.format(train_mse))
        print('train MAE: {}'.format(train_mae))
        print('train TOTAL: {}'.format(train_total))
        self.writer.add_scalar("Train/MSE", train_mse, epoch)
        self.writer.add_scalar("Train/MAE", train_mae, epoch)
        self.writer.add_scalar("Train/TOTAL", train_total, epoch)

    def valid(self, epoch):
        val_running_step = len(self.val_dataloader)

        self.model.eval()
        val_mse = 0
        val_mae = 0
        val_total = 0

        with torch.no_grad():
            for val_idx, (inputs, labels, _, _) in enumerate(self.val_dataloader):
                inputs = inputs.to(self.device)
                labels_state = labels.to(self.device)

                outputs = self.model(inputs)
                if self.model_type in ['RNN', 'LSTM', 'GRU']:
                    outputs = outputs[0][:, -1, :].unsqueeze(1)
                if self.model_type == 'DNN':
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)
                else:
                    if self.model_type[:7] == 'Stacked':
                        outputs = outputs.unsqueeze(1)
                    loss_mse = self.criterionMSE(outputs, labels_state)
                    loss_mae = self.criterionMAE(outputs, labels_state)

                val_mse += loss_mse.item()
                val_mae += loss_mae.item()
                val_total += val_mae + val_mse

        val_mse = val_mse / val_running_step
        val_mae = val_mae / val_running_step
        val_total = val_total / val_running_step

        print('val MSE: {}'.format(val_mse))
        print('val MAE: {}'.format(val_mae))
        print('val TOTAL: {}'.format(val_total))
        self.writer.add_scalar("Val/MSE", val_mse, epoch)
        self.writer.add_scalar("Val/MAE", val_mae, epoch)
        self.writer.add_scalar("Val/TOTAL", val_total, epoch)

        if val_total < self.best_total:
            self.best_epoch = epoch
            save('best', epoch, self.SAVE_PATH, self.model, self.optimizer)
            self.best_total = val_total
        save('last', epoch, self.SAVE_PATH, self.model, self.optimizer)

        if self.schedule:
            self.scheduler.step()

    def test(self):
        self.model.load_state_dict(torch.load(os.path.join(self.SAVE_PATH, 'best.path.tar'))['model_state_dict'])
        self.model.eval()

        mse = []
        mae = []

        with torch.no_grad():
            for inputs, labels, _, _ in self.test_dataloader:
                inputs = inputs.to(self.device)
                labels_state = labels.to(self.device)
                outputs = self.model(inputs)

                if self.model_type in ['RNN', 'LSTM', 'GRU']:
                    outputs = outputs[0][:, -1, :].unsqueeze(1)
                outputs = outputs.squeeze(1)
                mse.extend(((outputs - labels_state.squeeze(1)) ** 2).detach().cpu().numpy())
                mae.extend(abs(outputs - labels_state.squeeze(1)).detach().cpu().numpy())

        mse = np.array(mse).mean(axis=0)
        mae = np.array(mae).mean(axis=0)

        results_mse = {}
        results_mae = {}
        results = {}
        for idx in self.column_idx:
            results_mse[idx] = mse[self.column_idx[idx]].mean()
            results_mae[idx] = mae[self.column_idx[idx]].mean()

        results['MSE'] = sum(results_mse.values()) / len(list(results_mse.values()))
        results['MAE'] = sum(results_mae.values()) / len(list(results_mae.values()))
        results['avg'] = (results['MSE'] + results['MAE']) / 2

        results_df = pd.DataFrame.from_dict([results])
        results_df.to_csv(os.path.join(self.SAVE_PATH, 'test.csv'), index=False)
        print('test save path: ', os.path.join(self.SAVE_PATH, 'test.csv'))
        print('\n####################################################################\n')


def set_parameter_requires_grad(model, feature_extracting):
    if feature_extracting:
        for param in model.parameters():
            param.requires_grad = False


class DLPNet:
    def __init__(self, IN_FEAT, IN_SEQ, rate):
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        # self.device = 'cpu'
        self.agent = DNN(input_size=IN_FEAT * IN_SEQ, hidden_size=hid_dim, output_size=5).to(self.device)
        self.action_space = rate

    def get_policy(self, data):
        logits = self.agent(data)
        return Categorical(logits=logits)

    def get_action(self, obs):
        sample = self.get_policy(obs).sample()
        return sample

    def get_parameter(self, action):
        return [self.action_space[x] for x in action]

    def compute_logp(self, obs, act):
        logp = self.get_policy(obs).log_prob(act)
        return logp

    def compute_loss(self, logp, weights):
        return -(logp * weights).mean()

    def reward_to_go(self, rews):
        n = len(rews)
        rtgs = np.zeros_like(rews)
        for i in reversed(range(n)):
            rtgs[i] = rews[i] + (rtgs[i + 1] if i + 1 < n else 0)
        return rtgs


models = ['DNN', 'Seq2Seq_RNN', 'Seq2Seq_LSTM', 'Seq2Seq_GRU']
# models = ['Seq2Seq_RNN', 'Seq2Seq_LSTM', 'Seq2Seq_GRU']
epochs = 100
hid_dim = 256
n_layers = 4
window_size = 10
pred_len = 1
schedule = False
batch_size = 128

px4_path = 'JB_baseline/px4_normal_nanprocessed.csv'
dji_path = 'JB_baseline/dji_normal_processed.csv'

X_train, y_train, X_val, y_val, X_test, y_test, column_idx = get_sub_data(dji_path)

exp = [Baseline_RL]
rate = {'1': [(0.8, 1.2), (0.9, 1.1), (1.0, 1.0), (1.1, 0.9), (1.2, 0.8)],
        '2': [(0.6, 1.4), (0.8, 1.2), (1.0, 1.0), (1.2, 0.8), (1.4, 0.6)]}
grid = list(set(rate['1'] + rate['2']))
# seed = [42, 77, 123, 777, 1234, 12345]
seed = [77]
rl_lr = [0.1, 0.01, 0.001]

for seed_item in seed:
    for model_type in models:
        random_seed = seed_item
        torch.manual_seed(random_seed)
        torch.cuda.manual_seed(random_seed)
        torch.cuda.manual_seed_all(random_seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        np.random.seed(random_seed)
        random.seed(random_seed)
        for exp_item in exp:
            if exp_item == Baseline_RL:
                for rate_item in rate.keys():
                        for rl_lr_item in rl_lr:
                            exp_model = exp_item(model_type, hid_dim, n_layers, window_size, pred_len, schedule,
                                                 X_train, y_train, X_val, y_val, X_test, y_test, column_idx,
                                                 rate[rate_item], seed_item, rl_lr_item, rate_item, batch_size)
                            for epoch in range(1, epochs):
                                exp_model.train(epoch)
                                exp_model.valid(epoch)
                            exp_model.test()
                            del exp_model
            else:
                for grid_item in grid:
                    exp_model = exp_item(model_type, hid_dim, n_layers, window_size, pred_len, schedule, X_train,
                                         y_train, X_val, y_val, X_test, y_test, column_idx, seed_item, grid_item,
                                         batch_size)
                    for epoch in range(1, epochs):
                        exp_model.train(epoch)
                        exp_model.valid(epoch)
                    exp_model.test()
                    del exp_model


