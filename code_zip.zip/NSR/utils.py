import os, pickle
import random
import numpy as np
import pandas as pd
from tqdm import tqdm, trange
from glob import glob

import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torchvision.transforms as T
from torch.utils.data import DataLoader, Dataset

import plotly.io as pio
pio.renderers.default = 'notebook' # or 'notebook' or 'colab'
import plotly.graph_objects as go

import warnings
warnings.filterwarnings(action='ignore')

from sklearn.preprocessing import MinMaxScaler


def split_series(series, n_past, n_future):
    '''
    :param series: input time series
    :param n_past: number of past observations
    :param n_future: number of future series
    :return: X, y(label)
    '''
    X, y = list(), list()
    for window_start in range(len(series)):
        past_end = window_start + n_past
        future_end = past_end + n_future
        if future_end > len(series):
            break
        # slicing the past and future parts of the window
        past, future = series[window_start:past_end, :], series[past_end:future_end, :]
        X.append(past)
        y.append(future)
    return X, y


def add_meta(df):
    """
    Feature Engineering for months
    """
    meta = np.array([each.split(' ')[1:3] for each in df['timestamp']])
    month_arr = meta[:, 0]
    year_arr = meta[:, 1]

    df['month'] = month_arr
    df['year'] = year_arr
    return df


def save(state, epoch, save_dir, name, model, is_parallel=None):
    os.makedirs(save_dir, exist_ok=True)

    with open(save_dir + '/' + name + '_' + state + ".path.tar", "wb") as f:
        if not is_parallel:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict()}, f)
        else:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.module.state_dict()}, f)


def train_test_split(df, train_month, test_month, train_year, test_year: str, norm=True):
    """
    months: 상반기/하반기
    years : 연도

    return: numpy_arr (train/test) and meta (train/test dataframe)
    """

    train_month_idx = np.in1d(df['month'].values, train_month)
    train_year_idx = df['year'].values == train_year

    test_month_idx = np.in1d(df['month'].values, test_month)
    test_year_idx = df['year'].values == test_year

    train_idx = np.logical_and(train_month_idx, train_year_idx)
    test_idx = np.logical_and(test_month_idx, test_year_idx)

    train_df = df[train_idx]
    test_df = df[test_idx]

    if norm:
        s = MinMaxScaler()
        train = s.fit_transform(train_df.drop(['timestamp', 'month', 'year'], axis=1).values)
        test = s.transform(test_df.drop(['timestamp', 'month', 'year'], axis=1).values)
        return train, test, s, [train_df, test_df]

    else:
        train = train_df.values
        test = test_df.values
        return train, test, [train_df, test_df]


def get_dataset(path):
    K3As = sorted(os.listdir(path))[:2]
    K3s = sorted(os.listdir(path))[2:4]
    K5s = sorted(os.listdir(path))[4:]

    ELE_column_name = ['timestamp', 'Semi_major_axis', 'Eccentricity', 'Inclination', 'RAAN', 'Argument_of_perigee',
                       'Mean_anomaly']

    K3A_ELE_DF = pd.read_csv(path + K3As[0], names=ELE_column_name)
    K3_ELE_DF = pd.read_csv(path + K3s[0], names=ELE_column_name)
    K5_ELE_DF = pd.read_csv(path + K5s[0], names=ELE_column_name)

    # add month & year column
    K3A_ELE_DF = add_meta(K3A_ELE_DF)
    K3_ELE_DF = add_meta(K3_ELE_DF)
    K5_ELE_DF = add_meta(K5_ELE_DF)

    dataset_dict = {
        'K3A': K3A_ELE_DF,
        'K3': K3_ELE_DF,
        'K5': K5_ELE_DF,
    }

    return dataset_dict, K3A_ELE_DF.keys()[1: 7]


class CustomDataset(Dataset):

    def __init__(self, data, label):
        self.data = data
        self.label = label

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        data = self.data[idx]
        label = self.label[idx]
        return data, label


def action_step(states, actions, labels, origin_mse, action_size):
    print('states.shape', states.shape)  # torch.Size ([1, 18])
    print('actions.shape', actions.shape)  # torch.Size ([11, 6])
    # TODO: Numpy 계산 최적화 시키기
    for ind in range(len(actions)):
        modi = []
        for n, i in enumerate(actions[ind]):
            if i == 1:
                if n % 3 == 0:
                    modi.append(1.00-action_size)
                elif n % 3 == 1:
                    modi.append(1.00)
                else:
                    modi.append(1.00+action_size)

    print('states.shape', states.shape)
    print('np.array(modi).shape', np.array(modi).shape)
    states[-1, :] = states[-1, :] * np.array(modi)

    next_states = states
    reward, mse_loss, mae_loss = cal_reward(next_states, labels, origin_mse)

    return next_states, reward, mse_loss, mae_loss


def cal_reward(next_states, labels, origin_mse,):
    mse_loss = nn.MSELoss()
    mae_loss = nn.L1Loss()

    rl_mse = mse_loss(torch.from_numpy(next_states[-1, :]), torch.from_numpy(labels))
    rl_mae = mae_loss(torch.from_numpy(next_states[-1, :]), torch.from_numpy(labels))
    reward = origin_mse - rl_mse

    return reward*10000000, rl_mse, rl_mae