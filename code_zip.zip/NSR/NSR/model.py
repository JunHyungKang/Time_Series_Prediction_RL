import torch
import torch.nn as nn
import numpy as np


class DNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(DNN, self).__init__()
        
        self.linear = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            
            nn.Linear(hidden_size, output_size)
        )
        
    def forward(self, input):
        return self.linear(input)
    
    
    
class Encoder(nn.Module):
    def __init__(self, input_dim=6, output_dim=128, n_layers=4, model_type='RNN'):
        super().__init__()
        assert model_type in ['RNN','LSTM', 'GRU']
        
        self. output_dim = output_dim
        self.n_layers = n_layers
        
        self.cell = eval(f'nn.{model_type}(input_dim, output_dim, n_layers, batch_first=True)')
        self.fc = nn.Linear(output_dim, input_dim)
        
    def forward(self, src):
        self.cell.flatten_parameters()
        outputs, hidden = self.cell(src)
        outputs = self.fc(outputs)
        
        return outputs, hidden

class DecoderCell(nn.Module):
    def __init__(self, input_dim=6, output_dim=128, n_layers=4, model_type='RNN'):
        super().__init__()
        assert model_type in ['RNN','LSTM', 'GRU']
        
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.n_layers = n_layers
        
        self.cell = eval(f'nn.{model_type}(input_dim, output_dim, n_layers, batch_first=True)')
        self.fc = nn.Linear(input_dim, output_dim)
        
    def forward(self, x, hidden):
        output, hidden = self.cell(x, hidden)
        output = self.fc(output)
        
        return output, hidden

class Seq2Seq(nn.Module):
    def __init__(self, input_dim=6, output_dim=6, hid_dim=128, n_layers=4, model_type='RNN', pred_len=10, device='cuda'):
        super().__init__()
        self.device = device
        
        self.pred_len = pred_len
        self.output_dim = output_dim

        self.encoder = Encoder(input_dim, hid_dim, n_layers, model_type)
        self.decoder = DecoderCell(hid_dim, output_dim, n_layers, model_type)

       
    def forward(self, x):
        batch_size = x.shape[0]
        outputs, hidden = self.encoder(x)
        
        de_input = outputs[:, -1, :].unsqueeze(1)
        
        outputs = torch.zeros(batch_size, self.pred_len, self.output_dim, device=self.device)

        for t in range(1, self.pred_len):
            output, hidden = self.decoder(de_input, hidden)
            outputs[:, t, :] = output.squeeze(1)
            de_input = output
       
        return outputs    
